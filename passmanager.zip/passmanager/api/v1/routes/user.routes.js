const router = require("express").Router()
const rules = require('../middlewares').validatorschema
//const { virifyaccesstoken } = require('../middlewares').auth
const { userControllers } = require("../controllers")

router.route("/register").post(rules.check(rules.register,'body'), userControllers.register)
router.route("/otpverify/:mobileNumber/:mobileotp").get(rules.check(rules.otp,'params'), userControllers.otpverify)
router.route("/login").post(rules.check(rules.login,'body'), userControllers.login)
router.route("/forgetpassword/:mobileNumber").get(rules.check(rules.forgetpassword,'params'), userControllers.forgetpassword)
router.route("/forgetpasswordotp").post(rules.check(rules.forgetpasswordotp,'body'), userControllers.forgetpasswordotp)

module.exports = router