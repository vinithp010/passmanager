const router = require("express").Router();

router.use("/user", require("./user.routes"));
router.use("/", require("./password.routes"));

module.exports = router;