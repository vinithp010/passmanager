const router = require("express").Router();
const rules = require('../middlewares').validatorschema
const { virifyaccesstoken } = require('../middlewares').auth
const { passwordControllers } = require("../controllers");


router.route("/password/add").post(virifyaccesstoken, rules.check(rules.addpassword,'body'), passwordControllers.addpassword);
router.route("/password/readall/:userid").get(virifyaccesstoken, rules.check(rules.userid,'params'), passwordControllers.readallpassword)
router.route("/password/readone").post(virifyaccesstoken ,rules.check(rules.iduserid,'body'), passwordControllers.readonepassword)
router.route("/password/update").post(virifyaccesstoken ,rules.check(rules.updatepassword,'body'), passwordControllers.updatepassword)
router.route("/password/remove").post(virifyaccesstoken ,rules.check(rules.iduserid,'body'), passwordControllers.removepassword)
router.route("/category/add").post(virifyaccesstoken ,rules.check(rules.addcategory,'body'), passwordControllers.addcategory)
router.route("/category/remove").post(virifyaccesstoken ,rules.check(rules.iduserid,'body'), passwordControllers.removecategory)
router.route("/category/push").post(virifyaccesstoken ,rules.check(rules.updatecategory,'body'), passwordControllers.pushcategory)
router.route("/category/pull").post(virifyaccesstoken ,rules.check(rules.updatecategory,'body'), passwordControllers.pullcategory)
router.route("/category/readall/:userid").get(virifyaccesstoken ,rules.check(rules.userid,'params'), passwordControllers.readallcategory)
router.route("/category/readone").post(virifyaccesstoken, rules.check(rules.iduserid,'body'), passwordControllers.readonecategory)

module.exports = router;