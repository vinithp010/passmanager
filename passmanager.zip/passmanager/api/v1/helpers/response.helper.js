//const log = require('../helpers').logger

const errors = {
    404: {
        status: 404,
        errorCode: "Not Found"
    },
    500: {
        status: 500,
        errorCode: "internal Server Error"
    },
    400: {
        status: 400,
        errorCode: "Bad Request"
    },
    401: {
        status: 401,
        errorCode: "Unauthorized"
    },
    402: {
        status: 402,
        errorCode: "Payment Required"
    },
    403: {
        status: 403,
        errorCode: "Forbidden"
    }, 
    422: {
        status: 422,
        errorCode: "Unprocessable Entity"
    }
}

const success = {
    200 :{
        status: 200,
        successCode : "Ok"
    },
    201 :{
        status: 201,
        successCode : "Created"
    }
}

module.exports = {
    successResponse: (res, code, resData) => {
        res.status(success[code].status || code).json({
            status: 'SUCCESS',
            successCode: success[code].successcode || {},
            data : resData || {}
            
        })
    },
    errorResponse: (res, code, error) => {
        res.status(errors[code].status || code).json({
            status : 'ERROR',
            errorCode: errors[code].errorCode || {},
            error: error || {}
        })
    }
}