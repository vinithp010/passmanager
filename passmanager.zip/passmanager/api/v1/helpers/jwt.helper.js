const jwt = require('jsonwebtoken')
const config = require("../../../config/appConfig") 

const signaccesstoken = (data)=>{
    return new Promise((resolve,reject) =>{
        jwt.sign({"id" : data},config.JWT_SECTER_ACCESS_TOKEN,{ expiresIn: "100m" },(err, token) =>{
            if(err) console.log(err)
            resolve(token)
        })
    })
}

module.exports = {
    signaccesstoken
}