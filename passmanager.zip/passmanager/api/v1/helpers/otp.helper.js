const config = require(global.rootDirPath + '/config/appConfig')
const accountSid = config.TWILIO_ACCOUNT_SID
const authToken = config.TWILIO_AUTH_TOKEN
// const client = require('twilio')(accountSid, authToken)

const generateOTP = () => Math.floor(1000 + Math.random() * 9000)

const sendmobileotp = async (data) => {
    try {
        const info = await client.messages
        .create({
            body: data.mobileotp,
            from: config.MOBILENUMBER,
            to: data.mobileNumber
        })
        if(info) return info
    } catch (error) {
        console.log(error)
    } 
}

module.exports = {
    generateOTP,
    sendmobileotp
}