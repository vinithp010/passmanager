
const add = async (schema, data) => {
    try {
        const newmodel = new schema(data)
        const issave = await newmodel.save()
        if(issave) return issave
    } catch (error) {
        console.log(error)
    }
}

const read = async (schema, data) => {
    try {
        const issave = await schema.find(data)
        if(issave) return issave
    } catch (error) {
        console.log(error)
    }
}

const readone = async (schema, data) => {
    try {
        const issave = await schema.findOne(data)
        if(issave) return issave
    } catch (error) {
        console.log(error)
    }
}

const update = async (schema, search, data) => {
    try {
        const isupdate = await schema.findOneAndUpdate(search,data,{new : true})
        if(isupdate) return isupdate
    } catch (error) {
        console.log(error)
    }
}

const remove = async (schema, data) => {
    try {
        const isremove = await schema.remove(data)
        if(isremove) return isremove
    } catch (error) {
        console.log(error)
    }
}

const verifyotp = async(schema, search, data) => {
    try {
        const isupdate = await schema.findOneAndUpdate(search, data, {
            new: true
        })
        if(isupdate) return isupdate
    } catch (error) {
        console.log(error)
    }
}

const push = async(schema, search, data) => {
    try {
        const isupdate = await schema.findOneAndUpdate(search,{
            $push :data
        },{
            new: true
        })
        if(isupdate) return isupdate
    } catch (error) {
        console.log(error)
    }
}

const pull = async(schema, search, data) => {
    try {
        const isupdate = await schema.findOneAndUpdate(search,{
            $pull :data 
        },{
            new: true
        })
        if(isupdate) return isupdate
    } catch (error) {
        console.log(error)
    }
}

module.exports = {
    add,
    read,
    readone,
    update,
    remove,
    verifyotp,
    push,
    pull
}

