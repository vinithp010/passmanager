const jwt = require('jsonwebtoken')
const config = require("../../../config/appConfig")
const response = require("../helpers").response 

const virifyaccesstoken = (req, res, next)=>{
    try {
        if(!req.headers['authorization']) return response.errorResponse(res, 401, "Auth token require")
        const authheader = req.headers['authorization']
        const bearertoken = authheader.split(' ')
        const token = bearertoken[1]
        if(!token) return response.errorResponse(res, 401, "Auth token require")
        jwt.verify(token, config.JWT_SECTER_ACCESS_TOKEN, (err, payload) => {
            if(err) return response.errorResponse(res, 401)
            next()
        })
    } catch (error) {
        console.log(error)
    }
}

module.exports = {
    virifyaccesstoken
}