const validatorschema = require('./validator.middleware')
const auth = require('./auth.middleware')

module.exports ={
    validatorschema,
    auth
}