const joi = require('joi')
const response = require("../helpers").response

const id = joi.object({
  _id: joi.string().required()
})

const userid = joi.object({
  userid: joi.string().required()
})

const otp = joi.object({
    mobileNumber: joi.string().required(),
    mobileotp: joi.string().min(4).max(6).required()
})

const iduserid = joi.object({
    _id: joi.string().required(),
    userid: joi.string().required()
})

const register = joi.object({
  username: joi.string().min(3).max(30).required(),
  mobileNumber: joi.string().min(8).max(12).required(),
  password: joi.string().min(4).max(4).required()
})

const forgetpassword = joi.object({
  mobileNumber: joi.string().min(8).max(12).required()
})

const forgetpasswordotp = joi.object({
  mobileNumber: joi.string().min(8).max(12).required(),
  mobileotp: joi.string().min(4).max(6).required(),
  password: joi.string().min(4).max(4).required()
})

const login = joi.object({
  mobileNumber: joi.string().min(8).max(12).required(),
  password: joi.string().min(4).max(4).required()
})

const addpassword = joi.object({
    userid: joi.string().required(),
    sitename: joi.string().required(),
    siteurl:joi.string().required(),
    categoryid:joi.string().required(),
    password:joi.string().required(),
    note:joi.string(),
})

const updatepassword = joi.object({
    _id: joi.string().required(),
    userid: joi.string(),
    sitename: joi.string(),
    siteurl:joi.string(),
    categoryid:joi.string(),
    password:joi.string(),
    note:joi.string()
})

const addcategory = joi.object({
    name: joi.string().required(),
    userid: joi.string().required(),
    passwordid:joi.string()
})

const updatecategory = joi.object({
    _id: joi.string().required(),
    userid: joi.string(),
    passwordid:joi.string()
})


const check = (schema, property) => { 
  return (req, res, next) => { 
    const { error } = schema.validate(req[property]);
    const valid = error == null; 
    if (valid) { next(); } 
    else { 
      const { details } = error; 
      const message = details.map(i => i.message).join(',')
      console.log("error", message); 
      return response.errorResponse(res, 422, message)
    } 
  } 
}

module.exports = {
  id,
  userid,
  iduserid,
  register,
  otp,
  login,
  forgetpassword,
  forgetpasswordotp,
  addpassword,
  updatepassword,
  addcategory,
  updatecategory,
  check
}