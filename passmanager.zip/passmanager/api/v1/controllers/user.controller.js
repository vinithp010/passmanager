const response = require('../helpers').response
const  Helper = require("../helpers").common
const { generateOTP, sendmobileotp } = require("../helpers").otp
const { signaccesstoken } = require("../helpers").jwthelper
const { removeallpassword } = require("./password.controller")
// mongoose models
const user_Model = require('../models').user_model


const register = async (req, res) => { 
    try {
        const data = { 
            mobileNumber : req.body.mobileNumber
        }
        const isuser = await Helper.readone(user_Model,data)
        console.log(isuser)
        if(isuser) return response.errorResponse(res, 422, "user already exists")
        req.body.mobileotp = generateOTP()
        const isreg = await Helper.add(user_Model, req.body)
        if(!isreg) return response.errorResponse(res, 500, "unable to register")
        return response.successResponse(res, 201, isreg._id)
        
        /*const issentmobileotp = await sendmobileotp
        if(!issentmobileotp){
            res.send('ERROR: SOMETHING WENT WRONG')
            return                           
        }*/
        
       } catch (error) {
            console.log(error)
        }  
}

const otpverify = async (req, res) => {
    try {
        const search = {
            mobileNumber : req.params.mobileNumber,
            mobileotp : req.params.mobileotp
        }
        const data = {
            isMobileVerified : 'Verified',
            otpvalid : "false"
        }
        const isverify = await Helper.verifyotp(user_Model,search,data)
        if(!isverify) return response.errorResponse(res, 404 ,"otp not found")
        return response.successResponse(res, 200)
    } catch (error) {
        console(error)
    }
}

const login = async (req, res) => {
    try {
        const data = {
            mobileNumber : req.body.mobileNumber,
            password: req.body.password
        }
        const isread = await Helper.readone(user_Model, data)
        if(!isread) return response.errorResponse(res, 401, "username, password not found")
        if(isread.isMobileVerified=="Not") return response.errorResponse(res, 404 ,"verify the mobile")
        const jwttoken = await signaccesstoken({_id:isread._id})
        if(!jwttoken) return response.errorResponse(res, 500, "not able to generate jwt token")
        return response.successResponse(res, 200, jwttoken)
    } catch (error) {
        console.log(error)
    }
}

const forgetpassword = async (req, res) => {
    try {
        const data = {
            mobileNumber : req.params.mobileNumber
        }
        const isread = await Helper.readone(user_Model, data)
        if(!isread) return response.errorResponse(res, 404, "user not found")
        req.body.userid = isread._id
        if(isread.isreset=="true")return removeallpassword(req, res)
        const search ={
            _id: isread._id
        }
        data = {
            mobileotp : generateOTP(),
            otpvalid : "true"
        }
        const isupdate = await Helper.update(user_Model,search,data)
        if(!isupdate) return response.errorResponse(res, 500 ,"otp not generated")
        if(req.params.mobileNumber == isread.mobileNumber){
            const issentmobileotp = await sendmobileotp()
            //if(!issentmobileotp) return response.errorResponse(res, 500, "not able to send otp")
        }
        return response.successResponse(res, 200)
    } catch (error) {
        console.log(error)
    }
}

const forgetpasswordotp = async (req, res) =>{
    try {
        search = {
            mobileNumber: req.body.mobileNumber,
            mobileotp: req.body.mobileotp
        }
        const data ={
            password : req.body.password,
            otpvalid: "false",
            isreset: "true"
        }
        const isverify = await Helper.verifyotp(user_Model, search, data)
        if(!isverify) return response.errorResponse(res, 401, "otp not verified")
        return response.successResponse(res, 201)
    } catch (error) {
        console.log(error)
    }
}


module.exports = {
    register,
    otpverify,
    login,
    forgetpassword,
    forgetpasswordotp
}