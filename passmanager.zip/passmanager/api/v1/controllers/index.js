module.exports = {
    userControllers: require("./user.controller"),
    passwordControllers: require("./password.controller")
}