const response = require('../helpers').response
const  Helper = require("../helpers").common
// mongoose models
const password_Model = require('../models').password_model
const category_Model = require('../models').categories_model

const pushfunction = async (req) => {
    try {
        const search ={
            _id : req.body._id,
            userid : req.body.userid
            
        }
        const data = {
            passwordid :req.body.passwordid
        }
        return await Helper.push(category_Model,search,data)
        
    } catch (error) {
        console.log(error)
    }
}

const pullfunction = async (req) => {
    try {
        const search ={
            _id : req.body._id,
            userid : req.body.userid
        }
        const data = {
            passwordid :req.body.passwordid
        }
        return await Helper.pull(category_Model,search,data)
    } catch (error) {
        console.log(error)
    }
}


const addpassword = async (req, res) => {
    try {
        const isadd = await Helper.add(password_Model,req.body)
        if(!isadd) return response.errorResponse(res, 500, "password not added" )
        req.body.userid = isadd.userid
        req.body.passwordid = isadd._id
        req.body._id = isadd.categoryid
        const ispush = await pushfunction(req)
        if(!ispush) return response.errorResponse(res, 500, "password not added to category" )
        return response.successResponse(res,201,isadd)
    } catch (error) {
        console.log(error)
    }
}

const updatepassword = async (req, res) => {
    try {
        const search = {
            _id : req.body._id,
            userid : req.body.userid
        }
        const isupdate = await Helper.update(password_Model, search, req.body)
        if(!isupdate) return response.errorResponse(res, 500, "password not updated" )
        return response.successResponse(res,201,isupdate)
    } catch (error) {
        console.log(error)
    }
}

const readallpassword = async (req, res) => {
    try {
        const data = {
            userid : req.params.userid
        }
        const isread = await Helper.read(password_Model,data)
        if(!isread) return response.errorResponse(res, 404, "user not found")
        return response.successResponse(res,200,isread)
    } catch (error) {
        console.log(error)
    }
}

const readonepassword = async (req, res) => {
    try {
        const data = {
            _id: req.body._id,
            userid : req.body.userid
        }
        const isread = await Helper.readone(password_Model,data)
        if(!isread) return response.errorResponse(res, 404, "user or password not found")
        return response.successResponse(res,200,isread)
    } catch (error) {
        console.log(error)
    }
}

const removepassword = async (req, res) => {
    try {
        const data = {
            userid : req.body.userid,
            _id : req.body._id
        }
        const isremove = await Helper.remove(password_Model,data)
        if(!isremove) return response.errorResponse(res, 500, "password not removed")
        req.body.passwordid = req.body._id
        req.body._id = isremove.categoryid
        req.body.userid = req.body.userid
        console.log(req.body)
        const ispull = await pullfunction(req)
        if(!ispull) return response.errorResponse(res, 500, "password not removed from category")
        return response.successResponse(res,200,isremove)
    } catch (error) {
        console.log(error)
    }
}

const removeallpassword = async (req, res) => {
    try {
        const data = {
            userid : req.body.userid
        }
        console.log(data)
        const isremove = await Helper.remove(password_Model,data)
        if(!isremove) return response.errorResponse(res, 500, "password not removed")
        const isremoveca = await Helper.remove(category_Model,data)
        if(!isremoveca) return response.errorResponse(res, 500, "category not removed")
        return response.successResponse(res,200,"removed")
    } catch (error) {
        console.log(error)
    }
}

const addcategory = async (req, res) => {
    try {
        const isadd = await Helper.add(category_Model,req.body)
        if(!isadd) return response.errorResponse(res, 500, "unable to create category" )
        return response.successResponse(res,201,isadd)
    } catch (error) {
        console.log(error)
    }
}

const readallcategory = async (req, res) => {
    try {
        const data = {
            userid : req.params.userid
        }
        const isread = await Helper.read(category_Model,data)
        if(!isread) return response.errorResponse(res, 404, "user or password not found")
        return response.successResponse(res,201,isread)
    } catch (error) {
        console.log(error)
    }
}

const readonecategory = async (req, res) => {
    try {
        const data = {
            _id: req.body._id,
            userid : req.body.userid
        }
        const isread = await Helper.readone(category_Model,data)
        if(!isread) return response.errorResponse(res, 404, "user or password not found")
        return response.successResponse(res,201,isread)
    } catch (error) {
        console.log(error)
    }
}

const pushcategory = async (req, res) => {
    try {
        const isupdate = await pushfunction(req)
        if(!isupdate) return response.errorResponse(res, 404, "password not added to category")
        return response.successResponse(res,201,isupdate)
    } catch (error) {
        console.log(error)
    }
}

const pullcategory = async (req, res) => {
    try {
        const isupdate = await pullfunction(req)
        if(!isupdate) return response.errorResponse(res, 404, "password not removed from category")
        return response.successResponse(res,201,isupdate)
    } catch (error) {
        console.log(error)
    }
}

const removecategory = async (req, res) => {
    try {
        data ={
            _id : req.body._id,
            userid : req.body.userid
        }
        const isremove = await Helper.remove(category_Model,data)
        if(!isremove) return response.errorResponse(res, 404, "category not deleted")
        return response.successResponse(res,200,isremove)
    } catch (error) {
        console.log(error)
    }
}


module.exports = {
    addpassword,
    updatepassword,
    readallpassword,
    readonepassword,
    removepassword,
    addcategory,
    readallcategory,
    readonecategory,
    pushcategory,
    pullcategory,
    removecategory,
    removeallpassword

}