const user_model = require('./user.model')
const password_model = require('./password.model')
const categories_model = require('./category.model')


module.exports = {
    user_model,
    password_model,
    categories_model
}