const mongoose = require("mongoose"),
Schema = mongoose.Schema

const User = new Schema({
    username: String,
    mobileNumber: String,
    password: String,
    isreset: {
        type: String,
        enum: ["true", "false"],
        default:"false"
    },
    isMobileVerified: {
        type: String,
        enum: ["Not", "Verified"],
        default: "Not"
    },
    mobileotp: {
        type: String,
    },
    otpvalid:{
        type:String,
        enum: ["true", "false"],
        default:"true"
    }
}, {
    timestamps: true,
})

module.exports = mongoose.model("User", User)