const mongoose = require("mongoose"),
Schema = mongoose.Schema

const Password = new Schema({
    userid: {
        type : mongoose.Types.ObjectId,
        ref : "User"
    },
    sitename: String,
    siteuri: String,
    categoryid:{
        type : mongoose.Types.ObjectId,
        ref : "Category"
    },
    password: String,
    note: String
}, {
    timestamps: true,
})

module.exports = mongoose.model("Password", Password)