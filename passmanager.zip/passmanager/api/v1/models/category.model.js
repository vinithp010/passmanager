const mongoose = require("mongoose"),
Schema = mongoose.Schema

const Category = new Schema({
    name: String,
    userid: {
        type : mongoose.Types.ObjectId,
        ref : "User"
    },
    passwordid: [{
        type : mongoose.Types.ObjectId,
        ref : "User"
    }],
}, {
    timestamps: true,
})

module.exports = mongoose.model("Category", Category)