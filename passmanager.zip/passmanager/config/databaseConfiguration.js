const mongoose = require('mongoose')
const config = require("./appConfig")

const DBURI = config.database.DBURI

mongoose.connect(DBURI, { useNewUrlParser: true , useUnifiedTopology: true})
const db = mongoose.connection
console.log(DBURI)

db.on('connected', () => console.log('Mongoose default connection open to ' + DBURI))
    
// If the connection throws an error
db.on('error', err => console.log('Mongoose default connection error: ' + err))

// When the connection is disconnected
db.on('disconnected', () => console.log('Mongoose default connection disconnected'))
  
// If the Node process ends, close the Mongoose connection 
process.on('SIGINT', () => {   
    db.close(() => { 
      console.log('Mongoose default connection disconnected through app termination')
      process.exit(0)
    })
})

module.exports ={
    db
}