require("dotenv").config({path:'./.env'})

const MOBILENUMBER = process.env.MOBILENUMBER
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN 
const JWT_SECTER_ACCESS_TOKEN = process.env.JWT_SECTER_ACCESS_TOKEN
const JWT_SECTER_REFRESH_TOKEN = process.env.JWT_SECTER_REFRESH_TOKEN
const PORT = process.env.PORT

module.exports = {
    server: {
        PORT: 3000,
        NODE_ENVIR: "development", // enum: ["development", "production", "local"]
        domain: "http://localhost:3000"
    },
    database:{
        DBURI: process.env.DBURI
    },
    PORT,
    MOBILENUMBER,
    JWT_SECTER_ACCESS_TOKEN,
    JWT_SECTER_REFRESH_TOKEN,
    bcryptSaltRound: 10,
    staticFilesUrlRoute: "/static",
    showDevLogsAndResponse: false
}