const path = require("path")
global.rootDirPath = path.join(`${__dirname}`)
const express = require("express")
const app = express()
const logger = require("morgan")
const bodyParser = require("body-parser")
const cors = require("./config/cors")
const config = require("./config/appConfig")
const db = require('./config/databaseConfiguration')
require("dotenv").config({path:global.rootDirPath+'.env'})

app.use(logger("dev"))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.json({ limit: "50mb" }))
app.use(express.urlencoded({ limit: "50mb", extended: true }))
cors(app)

//app.use(config.staticFilesUrlRoute, express.static(path.join(__dirname, "..\\", config.uploadPath)))

app.use("/api", require("./api"))

app.use((req, res, next) => {
    const error = new Error(`404_Not Found - ${req.originalUrl}`)
    res.status(404)
    next(error)
})

app.use((err, req, res, next) => {
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode
    res.status(statusCode)
    res.json({
        msg: err.message,
        data: config.showDevLogsAndResponse ? err : err?.stack,
        errorCode: statusCode,
        success: false
    })
})

const PORT = process.env.PORT || config.server.PORT
const server = app.listen(PORT, () => {
    console.log(`Server: ListeningOn Port: ${PORT} And ${process.env.TEST_ENV ? "ENV variables fetch successfully!" : "can't get ENV variables"}`)
})